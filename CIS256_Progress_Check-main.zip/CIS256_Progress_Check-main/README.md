# CIS256 Progress Check

This is part b of the check for the python class.

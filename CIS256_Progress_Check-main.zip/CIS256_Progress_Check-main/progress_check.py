"""
Nicholas Triggs
Module 08 Lab Assignment
"""

# Use the empty print() statements to respond to the prompts below
print("The hardest part about learning Python so far is...")
print("Imports and testing first mindset")  # your response here
print("The most interesting part about learning Python so far is...")
print("inports are handy but the wording still confused me")
print("One thing related to Python I'd like to know more about is...")
print("testing we learned 1 command but it works")
print("One thing I'd tell future students about this course is...")
print("OOP is the goal dont let anyone fool you")
